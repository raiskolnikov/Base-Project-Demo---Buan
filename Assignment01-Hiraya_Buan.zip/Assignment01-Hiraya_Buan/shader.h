#pragma once

#include <fstream>
#include <glad/glad.h>
#include <iostream>
#include <sstream>
#include <string>

GLuint buildProgram(const std::string &vertPath, const std::string &fragPath) {
  std::ifstream vFile(vertPath), fFile(fragPath);
  if (!vFile.is_open()) {
    std::cerr << "Failed to open: " << vertPath << "\n";
    return 0;
  }
  if (!fFile.is_open()) {
    std::cerr << "Failed to open: " << fragPath << "\n";
    return 0;
  }

  std::stringstream vStream, fStream;
  vStream << vFile.rdbuf();
  fStream << fFile.rdbuf();

  std::string vertCode = vStream.str();
  std::string fragCode = fStream.str();
  const char *vertSrc = vertCode.c_str();
  const char *fragSrc = fragCode.c_str();

  auto compile = [](GLenum type, const char *src) {
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, nullptr);
    glCompileShader(s);
    int ok;
    char log[512];
    glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) {
      glGetShaderInfoLog(s, 512, nullptr, log);
      std::cerr << "Shader error: " << log << "\n";
    }
    return s;
  };

  GLuint vs = compile(GL_VERTEX_SHADER, vertSrc);
  GLuint fs = compile(GL_FRAGMENT_SHADER, fragSrc);
  GLuint p = glCreateProgram();

  glAttachShader(p, vs);
  glAttachShader(p, fs);

  glLinkProgram(p);

  glDeleteShader(vs);
  glDeleteShader(fs);

  return p;
}